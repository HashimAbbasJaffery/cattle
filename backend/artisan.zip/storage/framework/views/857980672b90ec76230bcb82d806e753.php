<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="UTF-8">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e(config('app.name', 'Laravel')); ?></title>
    <script src="https://kit.fontawesome.com/3a7e8b6e65.js" crossorigin="anonymous"></script>
    <link href="<?php echo e(asset('assets/css/output.css')); ?>" rel="stylesheet" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">   
    <script src="https://unpkg.com/vue@3/dist/vue.global.js"></script>
    <?php echo $__env->yieldPushContent("styles"); ?>
</head>
    <div class="relative"> 
        <?php echo e($slot); ?>

    </div>

    <?php echo $__env->yieldPushContent('scripts'); ?>
</html><?php /**PATH C:\Users\Abdul Moiz Elahi\Desktop\cattle2\backend\resources\views/layouts/guest.blade.php ENDPATH**/ ?>