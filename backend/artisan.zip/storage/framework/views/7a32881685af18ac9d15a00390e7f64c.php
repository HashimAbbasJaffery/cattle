
    <?php if (isset($component)) { $__componentOriginalb5f19f3ff27ef286a2c7343d075eb88f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb5f19f3ff27ef286a2c7343d075eb88f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.login','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('login'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container-scroller">
      <div class="container-fluid page-body-wrapper full-page-wrapper">
        <div class="content-wrapper d-flex align-items-center auth">
          <div class="row flex-grow">
            <div class="col-lg-4 mx-auto">
              <div class="auth-form-light text-left p-5">
                <div class="brand-logo">
                  <img src="<?php echo e(asset('/admin-panel/assets/images/logo.svg')); ?>">
                </div>
                <h4>Hello!</h4>
                <h6 class="font-weight-light">Sign in to continue.</h6>
                <form class="pt-3" action="<?php echo e(route('admin.login')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                  <div class="form-group">
                    <input type="email" class="form-control form-control-lg" name="email" id="exampleInputEmail1" placeholder="Email">
                  </div>
                  <div class="form-group">
                    <input type="password" class="form-control form-control-lg" name="password" id="exampleInputPassword1" placeholder="Password">
                  </div>
                  <div class="mt-3">
                    <button type="submit" class="btn btn-block btn-gradient-primary btn-lg font-weight-medium auth-form-btn">SIGN IN</button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
        <!-- content-wrapper ends -->
      </div>
      <!-- page-body-wrapper ends -->
    </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb5f19f3ff27ef286a2c7343d075eb88f)): ?>
<?php $attributes = $__attributesOriginalb5f19f3ff27ef286a2c7343d075eb88f; ?>
<?php unset($__attributesOriginalb5f19f3ff27ef286a2c7343d075eb88f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb5f19f3ff27ef286a2c7343d075eb88f)): ?>
<?php $component = $__componentOriginalb5f19f3ff27ef286a2c7343d075eb88f; ?>
<?php unset($__componentOriginalb5f19f3ff27ef286a2c7343d075eb88f); ?>
<?php endif; ?>
<?php /**PATH C:\Users\Abdul Moiz Elahi\Desktop\cattle2\backend\resources\views/admin/Auth/login.blade.php ENDPATH**/ ?>