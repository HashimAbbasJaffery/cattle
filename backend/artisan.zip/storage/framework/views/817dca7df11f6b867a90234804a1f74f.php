<?php if($paginator->hasPages()): ?>
    <section id="pagination">
        <div style="padding-left: 10px; text-align: center;" class="mobile-pagination mt-4 mb-3">
            <?php if($paginator->onFirstPage()): ?>
                <a href="#" class="pagination inline-block arrows">&lt;</a>
            <?php else: ?>
                <a href="<?php echo e($paginator->previousPageUrl()); ?>" class="pagination inline-block arrows">&lt;</a>
            <?php endif; ?>
            <?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(is_string($element)): ?>
                    <a href="#" class="pagination inline-block active"><?php echo e($element); ?></a>
                <?php endif; ?>

                <?php if(is_array($element)): ?>
                    <?php $__currentLoopData = $element; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($page == $paginator->currentPage()): ?>
                            <a href="#" class="pagination inline-block active"><?php echo e($page); ?></a>
                        <?php else: ?>
                            <a href="<?php echo e($url); ?>" class="pagination inline-block"><?php echo e($page); ?></a>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php if($paginator->onLastPage()): ?>
                <a href="#" class="pagination inline-block arrows">&lt;</a>
            <?php else: ?>
                <a href="<?php echo e($paginator->nextPageUrl()); ?>" class="pagination inline-block arrows">&gt;</a>
            <?php endif; ?>
        </div>
    </section>
<?php endif; ?>
<?php /**PATH C:\Users\Abdul Moiz Elahi\Desktop\cattle2\backend\resources\views/vendor/pagination/cattle.blade.php ENDPATH**/ ?>